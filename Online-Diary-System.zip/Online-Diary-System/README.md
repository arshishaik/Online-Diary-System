# Online-diary
Online diary is a PHP app by which you can write your feeling and keep it private or share with people and you can also read other post on shared tab if they shared . it is highly secure and there are so many intersting feature... 


#Installation
1)copy all the folder in web directory of your server .
2)import database(vote.sql) given in folder.
3)change dbconnection.php file according to your setting.Default username is root,password is null and database name is Vote.

for any feedback or query contact me at sunnygkp10@gmail.com
Your feedback are valuable to me...
thanx.
